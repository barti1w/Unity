﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public enum StanWalki {Start,TuraGracza,TuraWroga,Wygrana,Przegrana}
public class BattleManager : MonoBehaviour
{
    public StanWalki stan;
    public GameObject Bohater;
    public GameObject Potwór;

    public Vector3 PozycjaGracza;
    public Vector3 SkalaGracza;
    public Transform TrGracza;

    public Vector3 PozycjaWroga;
    public Vector3 SkalaWroga;
    public Transform TrWroga;

    Jednostka Wróg;
    Jednostka Gracz;

    public HUDWalki HUDGracza;
    public HUDWalki HUDWroga;

    public Button Atak;
    public Button Obrona;
    public Button Leczenie;

    public Text Tura;
    public Przyciski Przy;

    void Start()
    {
        stan = StanWalki.Start;
        TrGracza.localPosition = PozycjaGracza;
        TrGracza.localScale = SkalaGracza;


        TrWroga.localPosition = PozycjaWroga;
        TrWroga.localScale = SkalaWroga;
        SpawnPlayers();
    }
    void SpawnPlayers()
    {
        GameObject KlonGracza = Instantiate(Bohater, TrGracza);
        GameObject KlonWroga = Instantiate(Potwór, TrWroga);
        Gracz = KlonGracza.GetComponent<Jednostka>();
        Wróg = KlonWroga.GetComponent<Jednostka>();

        HUDGracza.Wyświetl(Gracz);
        HUDWroga.Wyświetl(Wróg);

        Przy.Turn(false);
        Tura.gameObject.SetActive(false);
        stan = StanWalki.TuraGracza;
        StartCoroutine(TuraGracza());
    }
    IEnumerator TuraGracza()
    {       
            yield return new WaitForSeconds(2f);
            Tura.gameObject.SetActive(true);
            Tura.text = "Twoja Tura";
            yield return new WaitForSeconds(1f);
            Tura.gameObject.SetActive(false);
            Przy.Turn(true);
            Atak.onClick.AddListener(Atakowanie);
            Obrona.onClick.AddListener(Bronienie);
            Leczenie.onClick.AddListener(Lecz);            
    }

    void TuraPotwora()
    {
        if (Wróg.ZdrowieTeraz <= 0)
        {
            stan = StanWalki.Wygrana;
            Wygrana();
        }        
        else if (Wróg.ZdrowieTeraz > 0)
        {

            int num = Random.Range(1, 4);            
            switch (num)
            {
                case 1:
                    {
                        Gracz.Bitwa(Wróg, Gracz);
                        HUDGracza.Wyświetl(Gracz);
                        Tura.text = "atak";
                        break;
                    }
                case 2:
                    {
                        Wróg.Bronienie(Wróg);
                        Tura.text = "bron";
                        break;
                    }
                case 3:
                    {
                        Tura.text = "Leczenie";
                        Wróg.leczenie(Wróg, 6);
                        HUDWroga.Wyświetl(Wróg);
                        break;
                    }
            }
            if (Gracz.ZdrowieTeraz < 0)
            {
                stan = StanWalki.Przegrana;
                Przegrana();
            }
            stan = StanWalki.TuraGracza;
            TuraGracza();
        }
        
    }

    void Atakowanie()
    {
        StartCoroutine(AAAAAA());
        stan = StanWalki.TuraWroga;
        TuraPotwora();
    }
      void Bronienie()
      {
          StartCoroutine(BBBBBB());
        stan = StanWalki.TuraWroga;
        TuraPotwora();
    }
      void Lecz()
      {
          StartCoroutine(CCCCCC());
        stan = StanWalki.TuraWroga;
        TuraPotwora();
    }
    IEnumerator AAAAAA()
    {
        Gracz.Bitwa(Gracz, Wróg);        
        HUDWroga.Wyświetl(Wróg);
        Tura.gameObject.SetActive(true);        
        Tura.text = "Zaatakowałeś za " + Gracz.obrażenia(Gracz,Wróg).ToString() + " obrażeń";
        yield return new WaitForSeconds(1f);
        Tura.gameObject.SetActive(false);       
    }

    IEnumerator BBBBBB()
    {
        Gracz.Bronienie(Gracz);              
        Tura.gameObject.SetActive(true);
        Tura.text = "Bronisz się";
        yield return new WaitForSeconds(1f);
        Tura.gameObject.SetActive(false);       
    }
    IEnumerator CCCCCC()
    {
        Gracz.leczenie(Gracz, 5);
        HUDGracza.Wyświetl(Gracz);
        Tura.gameObject.SetActive(true);
        Tura.text = "Uzdrowiłeś się za 5 punktów życia";
        yield return new WaitForSeconds(1f);
        Tura.gameObject.SetActive(false);        
    }
    public void Wygrana()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
    }
    public void Przegrana()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
    }
}
