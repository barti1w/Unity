﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jednostka : MonoBehaviour
{
    public float ZdrowieMax;
    public int atak;
    public int obrona;
    public bool isalive;
    public float ZdrowieTeraz;

   public void Bitwa (Jednostka atakujący, Jednostka obrońca)
    {
        obrońca.ZdrowieTeraz = obrońca.ZdrowieTeraz - atakujący.atak + obrońca.obrona;
    }
   public void Bronienie (Jednostka unit)
    {
        unit.obrona = unit.obrona+1;
    }
    public int obrażenia (Jednostka atakujący, Jednostka obrońca)
    {
        return atakujący.atak - obrońca.obrona;
    }
    public void leczenie(Jednostka unit, int ile)
    {
        unit.ZdrowieTeraz = unit.ZdrowieTeraz + ile;
      
        if(unit.ZdrowieTeraz>=unit.ZdrowieMax)
        {
            unit.ZdrowieTeraz = unit.ZdrowieMax;
        }
    }
    
}
